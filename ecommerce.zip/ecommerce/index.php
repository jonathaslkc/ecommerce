<?php
    $titulopage = 'Início - Templax E-commerce';
    $nomemenu   = 'inicio';
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    
    <?php include_once 'view/header/head.php'; ?>
    
</head><!--/head-->

<body>

    <?php include_once 'view/header.php'; ?>

    <?php include_once 'view/slider.php'; ?>

    <?php include_once 'view/corpo-produto.php'; ?>
	
    <?php include_once 'view/footer.php'; ?>
  


<!-- Scripts -->

    <script src="././web/js/jquery.js"></script>
    <script src="././web/js/bootstrap.min.js"></script>
    <script src="././web/js/jquery.scrollUp.min.js"></script>
    <script src="././web/js/price-range.js"></script>
    <script src="././web/js/jquery.prettyPhoto.js"></script>
    <script src="././web/js/main.js"></script>
    
<!-- /Scripts -->
</body>
</html>