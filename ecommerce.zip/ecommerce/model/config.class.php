<?php

define('DB_HOST', 'localhost');
define('DB_NAME', 'dhono');
//define('DB_NAME', 'db_ecommerce');
//define('DB_NAME', 'ecommerce_templaxcom635742');
//define('DB_USER', 'templax');
//define('DB_PASS', 'shin12@@');
define('DB_USER', 'root');
define('DB_PASS', '');