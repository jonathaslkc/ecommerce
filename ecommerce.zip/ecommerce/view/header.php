<header id="header"><!--header-->
		
    <?php include_once 'header/headertop.php'; ?>

    <?php include_once 'header/headermiddle.php'; ?>

    <?php include_once 'header/headerbottom.php'; ?>

</header><!--/header-->